

module pre_IF_stage(
    input wire [31:0]pc_i,
    input wire [31:0]instr,
    input wire [1:0]ID_sel_next_pc, 
    input wire [31:0]ID_imm,
    input wire [31:0]ID_reg_read_data1,
    input wire [31:0]ID_pc_plus_4,

    output wire [31:0]IF_pc_o,
    output wire [31:0]IF_pc_plus_4,
    output wire [31:0]IF_pc_plus_8,
    output wire pre_IF_ready_go
);


assign pre_IF_ready_go = 1'b1;

adder add(
.a(pc_i),
.b(32'd4),
.result(IF_pc_plus_4)
);

adder add_jal(
    .a(IF_pc_plus_4),
    .b(32'd4),
    .result(IF_pc_plus_8)
);

mux4 next_pc(
.data0(IF_pc_plus_4),
.data1(ID_pc_plus_4+{ID_imm[29:0],2'b00}),//BranchTarget
.data2({ID_pc_plus_4[31:28],instr[25:0],2'b00}),//J|JalTarget
.data3(ID_reg_read_data1),//jrTarget
.sel(ID_sel_next_pc),
.result(IF_pc_o)
);

endmodule