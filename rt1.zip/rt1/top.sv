module top(
    input logic clk,
    input logic rst
);

logic [31:0] inst_addr;
logic [31:0] inst_rdata;

cpu cpu_u(
    .clk(clk),
    .rst(rst),

    .inst_addr(inst_addr),
    .inst_rdata(inst_rdata)
);

imem imem_u(
    .clk(clk),
    .a(inst_addr),
    .en(1'b1),
    .rd(inst_rdata)
);

endmodule