module imem(
    input logic clk,
    input logic en,
    input logic [31:0]a,
    output logic [31:0]rd
);

logic [31:0] RAM[225:0];

initial begin

$readmemh("D:/Project/CPU/my_CPU/memfile.dat",RAM);

end

initial begin
    $readmemh("D:/Project/CPU/my_CPU/memfile.dat",RAM);
    $display("IMEM RAM[64] = %h", RAM[64]);
end

assign rd = en ? RAM[a[31:2]] : 32'b0;

endmodule


